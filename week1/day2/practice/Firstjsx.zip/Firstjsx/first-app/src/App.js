
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>HELLO DOJO !!</h1>
      <h3>things i need to do</h3>
      <ul>
        <li>learn react</li>
        <li>climb mt everest</li>
        <li>run a marathon</li>
        <li>feed the dogs</li>
        

      </ul>
    </div>
  );
}

export default App;
